README
--------------
Datasets:

HTRU2: https://raw.githubusercontent.com/charlieaxle/cs7461_1/master/HTRU_2.csv
Letter Recognition: https://raw.githubusercontent.com/charlieaxle/cs7461_1/master/letters_data.csv
--------------

Instructions to Run Code

1. Install latest version of Anaconda.
2. Open Jupyter notebook.
3. Run through .ipynb files for each dataset (letters.ipynb and HTRU2.ipynb).

